package com.ischoolbar.programmer.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;


import com.ischoolbar.programmer.entity.School;

/**
 * ѧУdao
 * @author ZYR
 *
 */
@Repository
public interface SchoolDao{
	public int add(School school);
	public int edit(School school);
	public int delete(String ids);
	public List<School> findList(Map<String,Object> queryMap);
	public List<School> findAll();
	public int getTotal(Map<String,Object> queryMap);
}
