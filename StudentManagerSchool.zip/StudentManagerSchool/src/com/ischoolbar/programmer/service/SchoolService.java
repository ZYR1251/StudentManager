package com.ischoolbar.programmer.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ischoolbar.programmer.entity.School;

/**
 * ѧУdao
 * @author ZYR
 *
 */
@Service
public interface SchoolService {
	public int add(School school);
	public int edit(School school);
	public int delete(String ids);
	public List<School> findList(Map<String,Object> queryMap);
	public List<School> findAll();
	public int getTotal(Map<String,Object> queryMap);
}

